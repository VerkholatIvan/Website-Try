This website was made by Ivan Verkholat for the Web Development course on International Year One.


!!! Before opening the site YOU MUST unzip the file by pressing with right mouse button and select "EXTRACT ALL"!!!

If the conditions will not be met, the website will not work.



to start interacting with my website open the "index.html" file.